<?php

	$to = "colin@koenig.us";
	
	$subject = "form Submission Enquirey";
	//if(isset($_POST['submitbtn']) )
   //{
	
		$name = $_POST['form-name'];
		$email = $_POST['form-email'];
		$company = $_POST['form-company'];
		$subject = $_POST['form-subject'];
		$message = $_POST['message'];
		
		$txt = "
			<table border=0 style='width:600px;'>
			<tr><td style='width:50%'>Name</td><td style='width:50%'>$name</td></tr>
			<tr><td style='width:50%'>Email</td><td style='width:50%'>$email</td></tr>
			<tr><td style='width:50%'>Company</td><td style='width:50%'>$company</td></tr>
			<tr><td style='width:50%'>Subject</td><td style='width:50%'>$subject</td></tr>
			<tr><td style='width:50%'>Message</td><td style='width:50%'>$message</td></tr>
			</table>";
			
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From:'.$name. '<info@baresfuertoner.de>' . "\r\n";
		$headers .=  "Reply-To: $email" . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
					
		if(mail($to,$subject,$txt,$headers)){
			echo "Mail sent successfully";
		}else{
			echo "Mail not sent error";
		}
   
   //}
?>




