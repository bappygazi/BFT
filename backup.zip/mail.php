<?php
 
    require ("class.phpmailer.php");
//if(isset($_POST['submitbtn1']) ){
        $fname=$_POST['form-name']; // Get fisrt Name value from HTML Form
        $email=$_POST['form-email'];  // Get Email Value
        $subject=$_POST['form-subject'];  // Get country Value
        $phone=$_POST['form-telefon'];  // Get Mobile No
        $message=$_POST['message']; // Get code Value
         
         
        $mail = new PHPMailer();
         $mail->SMTPSecure = 'ssl';
        $mail->IsSMTP();
        $mail->Host = "mail.baresfuertoner.de"; // Your Domain Name
         
        $mail->SMTPAuth = true;
        $mail->Port = 465;
        $mail->Username = "info@baresfuertoner.de"; // Your Email ID
        $mail->Password = "6jF-nRWowNGg"; // Password of your email id
         
        
        $mail->From = "info@baresfuertoner.de";
        $mail->FromName = "Attachment form Lead";
        $mail->AddAddress ("colin@koenig.us"); // On which email id you want to get the message
		// mail copy to any address
        //$mail->AddCC ($email);
		
		 // multiple file attachments
		 //<input type="file" multiple="multiple" name="attach_file[]" accept="image/*" />
		 for($ct=0;$ct<count($_FILES['attach_file']['tmp_name']);$ct++){
         $mail->AddAttachment($_FILES['attach_file']['tmp_name'][$ct],$_FILES['attach_file']['name'][$ct]);
        }
		 /***************************/
        
		 
		 
        $mail->IsHTML(true);
         
        $mail->Subject = "New Lead submitted by $fname"; // This is your subject
         
        // HTML Message Starts here
         
        $mail->Body = "
        <html>
            <body>
                <table style='width:600px;'>
                    <tbody>
                        <tr>
                            <td style='width:150px'><strong>Name: </strong></td>
                            <td style='width:400px'>$fname</td>
                        </tr>
						
                        <tr>
                            <td style='width:150px'><strong>Email ID: </strong></td>
                            <td style='width:400px'>$email</td>
                        </tr>
                        <tr>
                            <td style='width:150px'><strong>Phone: </strong></td>
                            <td style='width:400px'>$phone</td>
                        </tr>
						<tr>
                            <td style='width:150px'><strong>Subject: </strong></td>
                            <td style='width:400px'>$subject</td>
                        </tr>
                        <tr>
                            <td style='width:150px'><strong>Message: </strong></td>
                            <td style='width:400px'>$message</td>
                        </tr>
                    </tbody>
                </table>
            </body>
        </html>
        ";
        // HTML Message Ends here
         
             
        if(!$mail->Send()) {
            // Message if mail has been sent
            echo "mail not sent error";
        }
        else {
            // Message if mail has been not sent
            echo "mail sent successfully.";
        }
 
   //}
?>